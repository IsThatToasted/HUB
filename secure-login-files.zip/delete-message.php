<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="styles.css">
	<title>Secure login system with php and mysql</title>
</head>
<body>
	<div class="page">
		<h2>Your account is deleted </h2>
		<h4>You can create a new account</h4>
		<a href="index.php">Create a new account</a>
	</div>
</body>
</html>
