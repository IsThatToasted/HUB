<?php 
	session_start();
	define('SERVER', 'localhost'); // Fill in your server's name.
	define('USERNAME', ''); // Fill in your database username.
	define('PASSWORD', ''); // Fill in your database password if any.
	define('DATABASE', 'tutorials'); // Fill in your database.
